ace.define("ace/snippets/soy_template",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "soy_template";

});                (function() {
                    ace.require(["ace/snippets/soy_template"], function(m) {
                        if (typeof module == "object" && typeof exports == "object" && module) {
                            module.exports = m;
                        }
                    });
                })();
            